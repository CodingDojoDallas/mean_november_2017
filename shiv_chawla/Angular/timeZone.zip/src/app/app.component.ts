import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent { //what info to display inside of my component
  title:string;
  buttons: Array<string>;
  time:number;
  prettyTime:Date;

  constructor() {
    this.title = 'time Zone App'

  }

  generate(){
    this.buttons = ['PST','CST','EST','MST','clear'];
    let time_zone = []
    console.log(this.buttons)
  }

  ngOnInit(){
    console.log('shit init')
    this.generate();
  }

  changeTime(button){
    
    console.log('change')
    this.time;
    this.prettyTime;
    if (button == 'CST'){
      this.time = (Date.now());
      this.prettyTime = new Date(this.time);
    }
    else if (button == 'EST'){
      this.time = (Date.now() + 3600000 );
      this.prettyTime = new Date(this.time);
    }
    else if (button == 'MST'){
      this.time = (Date.now() - 3600000 );
      this.prettyTime = new Date(this.time);
    }
    else if (button == 'PST'){
      this.time = (Date.now() - 7200000 );
      this.prettyTime = new Date(this.time);
    }
    else if (button == 'clear'){
      this.prettyTime = '';
    }
  }

  showTime(button){
    console.log(button)
    this.changeTime(button)
  }

}



