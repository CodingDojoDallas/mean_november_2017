import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  people = [
    { email : "shiv@shiv.com",
      importance : false,
      subject : 'I',
      content : 'love wine'
    },
    { email : "cooper@cooper.com",
    importance : true,
    subject : 'I',
    content : 'love hickory sauce'
    },
    { email : "remy@remy.com",
    importance : false,
    subject : 'I',
    content : 'love salt'
    },
    { email : "harshil@harshil.com",
    importance : true,
    subject : 'I',
    content : 'love sleeping'
    }
  ];
}
