import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  users = [];
  user :object = { //create the object in the component class
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    confirm_password: '',
    street_address: '',
    unit: '',
    city: '',
    state: '',
  }
  constructor(){
    this.users = [];
    this.user;
  }
    onSubmit() {
      console.log(this.user)
      this.users.push(this.user)
    }

  
}
