import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class GetService {

  username : string;
  score : number;
  followers : number;
  repos : number;

  constructor(private _http: Http) { }
    get(username, cb){//create the function in your SERVICE but, call it in the component
      this._http.get('Https://api.github.com/users/'+username).subscribe(
        (response) => { //callback if you get a response
          cb(response.json());
          },
        (error) => { console.log(error); } //callback if you get errors
      );
    }
}
