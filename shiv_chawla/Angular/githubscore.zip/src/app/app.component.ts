import { Component } from '@angular/core';
import {GetService} from './get.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  github_username: string;
  user: object;
  followers: number;
  score: number;
  constructor( private _getService: GetService){
  }
  get(github_username){
    console.log(github_username.value)
    this._getService.get(github_username.value, user =>{
      this.score = this.calculate(user)
      console.log(user)
      console.log(this.score)
      return this.score
    })
  }
  calculate(user){
    return user.followers * 2 * user.public_repos
  }
}
