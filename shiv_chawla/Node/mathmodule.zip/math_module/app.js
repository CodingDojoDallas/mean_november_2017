var myMath = require('./mathlib');

console.log(myMath.add(1,2));
console.log(myMath.square(2));
console.log(myMath.random(1,9));
console.log(myMath.multiply(1,4));