
var express = require('express');

var app = express();

var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));

var path = require('path');

var mongoose = require('mongoose');
//connect to the mongodb using GOD and our specific db. It should auto create the db
mongoose.connect('mongodb://localhost/pack')

var PackSchema = new mongoose.Schema({
    name: { type: String, required: true, minlength: 1},
    color: { type: String, required: true, minlength: 1},
}, { timestamps: true } );

mongoose.model('Pack', PackSchema); 

var Pack = mongoose.model('Pack'); 
// Use native promises
mongoose.Promise = global.Promise;

app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');

app.get('/', function(req, res) {
    Pack.find({},function(err,animals){
        var animals = animals;
        res.render('index', {animals:animals}); //make sure the render is IN the function ALWAYS due to scope and shit
    })
})

app.get('/animals/new', function(req, res) {
    res.render('new');
})

app.post('/animals', function(req, res) {
    console.log("POST DATA", req.body);
    var pack = new Pack({name: req.body.name,color: req.body.color})
    pack.save(function(err){
        if(err){
            console.log('err');
        } else{
            console.log('success');
            res.redirect('/');
        }
    })
})

app.post("/animals/destroy/:id", function (request, response){
    id = request.params.id;
    console.log(id);
    Pack.remove({_id: id},function(err){
        response.redirect('/'); //make sure the render is IN the function ALWAYS due to scope and shit
    })
});

app.get("/animals/:id", function (request, response){

    id = request.params.id;
    Pack.find({_id:id},function(err,animal){
        response.render('animal', {animal:animal});
    })
});

app.post("/animals/:id", function (request, response){
    id = request.params.id;
    console.log(id)
    name = request.body.name;
    console.log(name)
    color = request.body.color;
    console.log(color)
    Pack.update({_id:id}, {name:name,color:color} ,function(err){
        response.redirect('/')
    })
});

app.get("/animals/edit/:id", function (request, response){
    id = request.params.id;
    Pack.find({_id:id},function(err,animal){
        console.log(id);
        response.render('edit', {animal:animal});
    })
});

// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})