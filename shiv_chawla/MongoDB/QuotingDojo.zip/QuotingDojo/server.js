// Require the Express Module
var express = require('express');
// Create an Express App
var app = express();
// Require body-parser (to receive post data from clients)
var bodyParser = require('body-parser');
// Integrate body-parser with our App
app.use(bodyParser.urlencoded({ extended: true }));
// Require path
var path = require('path');
// Require Mongoose
var mongoose = require('mongoose');
//connect to the mongodb using GOD and our specific db. It should auto create the db
mongoose.connect('mongodb://localhost/quotes')
var QuoteSchema = new mongoose.Schema({
    name: { type: String, required: true, minlength: 5},
    quote: { type: String, required: true, minlength: 10},
}, { timestamps: true } );
mongoose.model('Quote', QuoteSchema); //we are setting this schema in models to be "quote"
var Quote = mongoose.model('Quote'); //we are retrieving this schema from our models name quote
// Setting our Static Folder Directory
// Use native promises
mongoose.Promise = global.Promise;
app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request
app.get('/', function(req, res) {
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
    res.render('index');
})

app.post('/post', function(req, res) {
    console.log("POST DATA", req.body);
    //create a new quote with the name and quote corresponding to those from the req body
    var quote = new Quote({name: req.body.your_name,quote: req.body.quote})
    quote.save(function(err){
        if(err){
            console.log('err');
        } else{
            console.log('success');
            res.redirect('/result');
        }
    })
})

app.get('/result',function(req, res){
    var quotes = Quote.find({},function(err,quotes){
        console.log(quotes);
    res.render('result',{quotes:quotes});
    })

})
// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})