const math = require('./mathlib.js')();

math.add(1, 50);
math.multiply(25, 2);
math.square(5);
math.random(50, 10);
