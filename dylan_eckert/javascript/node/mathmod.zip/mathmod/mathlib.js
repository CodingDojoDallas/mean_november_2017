module.exports = function (){
  return {
    add: function(num1, num2) {
         console.log("the sum is: ", num1 + num2);
    },
    multiply: function(num1, num2) {
         console.log("the result is: ", num1 * num2);
    },
    square: function(num) {
         console.log("the square is: ", num * num);
    },
    random: function(num1, num2) {
        var random = Math.random();
        console.log("The random number is: "+random);
        var number = Math.floor(random * (num2-num1+1));
        console.log("The number equal to "+random+" * "+num2+" - "+num1+" + 1 is: "+ number);
        console.log("The random number between "+num1+" and "+num2+" is "+(number+num1)+", this is the sum of "+number+" + "+num1+"(the value of the first/lowest number given)");
    }
  }
};
