var mathlib = require('./mathlib')();

console.log(mathlib);
mathlib.add(2,5);
mathlib.multiply(4,3);
mathlib.square(8);
mathlib.random(27,53);
