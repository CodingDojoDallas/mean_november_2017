// get the http module:
var http = require('http');
// fs module allows us to read and write content for responses!!
var fs = require('fs');
// creating a server using http module:
var server = http.createServer(function(request, response) {
  // see what URL the clients are requesting:
  console.log('client request URL: ', request.url);
  // this is how we do routing:
  // +==================================+
  // EXPERIMENT WITH OPTOMIZING URL CODE
  // one method that handles all html, one for all imgs, one for all css(try using multiple ccs files).
  var myurls = {
    '/cars': {
      'file': 'cars.html',
      'content': 'text/html'
    },
    '/cats': {
      'file': 'cats.html',
      'content': 'text/html'
    },
    '/cars/new': {
      'file': 'carsnew.html',
      'content': 'text/html'
    },
    '/stylesheets/styles.css': {
      'file': 'stylesheets/styles.css',
      'content': 'text/css'
    },
    '/images/mcqueen.jpg': {
      'file': 'images/mcqueen.jpg',
      'content': 'image/jpg'
    },
    '/images/mator.jpg': {
      'file': 'images/mator.jpg',
      'content': 'image/jpg'
    },
    '/images/poolcat.jpg': {
      'file': 'images/poolcat.jpg',
      'content': 'image/jpg'
    },
    '/images/supercat.jpg': {
      'file': 'images/supercat.jpg',
      'content': 'image/jpg'
    },
  }
  // check to see if the request.url exists in myurls, if it does, serve content, if not, serve 404 error

  if (request.url in myurls) {
    fs.readFile(myurls[request.url]['file'], function(errors, contents) {
      response.writeHead(200, {
        'Content-Type': myurls[request.url]['content']
      });
      response.write(contents);
      response.end();
    });
  } else {
    response.end('File not found!!!');
  }
});
// tell your server which port to run on
server.listen(6789);
// print to terminal window
console.log("Running in localhost at port 6789");
