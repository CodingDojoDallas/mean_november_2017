// requirements
var express = require('express');
    mongoose = require('mongoose');
    bodyParser = require('body-parser');
    path = require('path');
    app = express();

// Integrating body-parser
app.use(bodyParser.urlencoded({
  extended: true
}));

// Mongoose code
// Connecting to mongo database and creating it if the db does not already exist
mongoose.connect('mongodb://localhost/mongoosedash');
// Creating QuoteSchema
var MongooseSchema = new mongoose.Schema({
  // NEED the required:true feild in order for errors to occur!
  name: {type:String, required: true},
  age: {type:Number, required: true},
}, {timestamps:true});
// Setting this schema in our models to be called 'Quote'
mongoose.model('Mongoose', MongooseSchema);
var Mongoose = mongoose.model('Mongoose');

// Setting views/static directories
app.use(express.static(path.join(__dirname, '/static')));
app.set('views', path.join(__dirname, '/views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');

// Routes
// homepage
app.get('/', function(req, res){
  // logic for getting all mongooses and rendering to the page
  Mongoose.find({}, function(err, mongooses) {
    if (err) {console.log(err);}
    console.log(mongooses);
    res.render('index', { mongooses: mongooses });
  });
});
// new mongoose form page
app.get('/mongooses/new', function(req, res) {
  res.render('newmon')
});
// edit mongoose page
app.get('/mongooses/edit/:name', function(req, res) {
  Mongoose.find({name: req.params.name}, function(err, mongoose){
    if (err) {console.log(err);}
    console.log(mongoose);
    res.render('editmon', { mongoose: mongoose });
  });
});
// profile page
app.get('/mongooses/:name', function(req, res) {
  Mongoose.find({name: req.params.name}, function(err, mongoose){
    if (err) {console.log(err);}
    console.log(mongoose);
    res.render('monprof', { mongoose: mongoose });
  });
});
// process a new mongoose
app.post('/mongooses', function(req, res) {
  let mongoose = new Mongoose (req.body);
  mongoose.save(function(err, mongoose){
    if (err) {
        console.log(err);
        return res.redirect('/mongooses/new');
    }else {
      console.log(mongoose)
      return res.redirect('/');
    }
  });
});
// process an edited mongoose
app.post('/mongooses/:name', function(req, res) {
  Mongoose.update({name: req.params.name}, req.body, function(err){
    if (err) {
        console.log(err);
        return res.redirect('/mongooses/edit/' + req.params.id);
    }else {
      return res.redirect('/');
    }
  });
});
// destroy mongoose
app.get('/mongooses/destroy/:name', function(req, res) {
  Mongoose.remove({name: req.params.name}, function(err){
    if (err) {console.log(err);}
    res.redirect('/');
  });
});
// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
  console.log("listening on port 8000");
})
