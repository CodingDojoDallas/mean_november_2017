// requirements
var express = require('express');
    mongoose = require('mongoose');
    bodyParser = require('body-parser');
    path = require('path');
    app = express();

// Integrating body-parser
app.use(bodyParser.urlencoded({
  extended: true
}));

// Mongoose code
// Connecting to mongo database and creating it if the db does not already exist
mongoose.connect('mongodb://localhost/messageboard');
var Schema = mongoose.Schema;
// Creating QuoteSchema
var MessageSchema = new mongoose.Schema({
  // NEED the required:true feild in order for errors to occur!
  author: {type:String, required: true},
  message: {type:String, required: true},
  _comments: [{type:Schema.Types.ObjectId, ref:'Comment'}],
}, {timestamps:true});
MessageSchema.path('author').required(true, 'Author cannot be blank');
MessageSchema.path('message').required(true, 'Message cannot be blank');
mongoose.model('Message', MessageSchema);
var Message = mongoose.model('Message');

var CommentSchema = new mongoose.Schema({
  _message: {type:Schema.Types.ObjectId, ref: 'Post'},
  creator: {type:String, required: true},
  comment: {type:String, required: true},
}, {timestamps:true});
CommentSchema.path('creator').required(true, 'Creator cannot be blank');
CommentSchema.path('comment').required(true, 'Comment cannot be blank');
mongoose.model('Comment', CommentSchema);
var Comment = mongoose.model('Comment');

// Setting views/static directories
app.use(express.static(path.join(__dirname, '/static')));
app.set('views', path.join(__dirname, '/views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');

// Routes
// homepage
app.get('/', function(req, res){
  // logic for getting all messages and their comments and rendering to the page
  Message.find({},false, true).populate('_comments').exec(function(err, messages){
    console.log(messages)
      res.render('index', { messages: messages });
    });
  });
// process a new message
app.post('/message', function(req, res) {
  let message = new Message ({author: req.body.author, message: req.body.message});
  message.save(function(err){
    if (err) {
        console.log(err);
    }else {
      console.log("success")
    }
    res.redirect('/');
  });
});
// process a new comment
app.post('/comment/:id', function(req, res) {
  var messageId = req.params.id;
  Message.findOne({_id: messageId}, function(err, message){
    let comment = new Comment ({creator: req.body.creator, comment: req.body.comment});
    comment._message = message._id;
    Message.update({ _id: message._id }, { $push: { _comments: comment }}, function(err){

    });
    comment.save(function(err){
        if (err) {
            console.log(err);
        }else {
            res.redirect('/');
        }
    });
  });
});
// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
  console.log("listening on port 8000");
})
