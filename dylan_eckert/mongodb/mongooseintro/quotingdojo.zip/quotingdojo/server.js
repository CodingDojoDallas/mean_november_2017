// requirements
var express = require('express');
    mongoose = require('mongoose');
    bodyParser = require('body-parser');
    path = require('path');
    app = express();

// Integrating body-parser
app.use(bodyParser.urlencoded({
  extended: true
}));

// Mongoose code
// Connecting to mongo database and creating it if the db does not already exist
mongoose.connect('mongodb://localhost/quotingdojo');
// Creating QuoteSchema
var QuoteSchema = new mongoose.Schema({
  // NEED the required:true feild in order for errors to occur!
  name: {type:String, required: true},
  quote: {type:String, required: true},
}, {timestamps:true});
// Setting this schema in our models to be called 'Quote'
mongoose.model('Quote', QuoteSchema);
var Quote = mongoose.model('Quote');

// Setting views/static directories
app.use(express.static(path.join(__dirname, '/static')));
app.set('views', path.join(__dirname, '/views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');

// Routes
app.get('/', function(req, res){
  res.render('index');
});
app.get('/quotes', function(req, res) {
  // logic for getting all quotes and rendering to the page
  Quote.find({}, function(err, quotes) {
    if (err) {console.log(err);}
    console.log(quotes);
    res.render('quotes', { quotes: quotes });
  });
});
app.post('/quotes', function(req, res) {
  let quote = new Quote (req.body);
  quote.save(function(err, quote){
    if (err) {
        console.log(err);
        return res.redirect('/');
    }else {
      console.log(quote)
      return res.redirect('/quotes');
    }
  });
});

// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
  console.log("listening on port 8000");
})
