var mongooses = require('../controllers/mongooses.js');
module.exports = function(app) {
  // Routes
  // GETTERS/GET
  // homepage
  app.get('/', function(req, res){
    mongooses.showAll(req, res);
  });
  // new mongoose form page
  app.get('/mongooses/new', function(req, res) {
    res.render('newmon')
  });
  // edit mongoose page
  app.get('/mongooses/edit/:name', function(req, res) {
    mongooses.showEdit(req, res);
  });
  // profile page
  app.get('/mongooses/:name', function(req, res) {
    mongooses.showProf(req, res);
  });
  // destroy mongoose
  app.get('/mongooses/destroy/:name', function(req, res) {
    mongooses.destroy(req, res);
  });
  // SETTERS/POST
  // process a new mongoose
  app.post('/mongooses', function(req, res) {
    mongooses.create(req, res);
  });
  // process an edited mongoose
  app.post('/mongooses/:name', function(req, res) {
    mongooses.update(req, res);
  });
}
