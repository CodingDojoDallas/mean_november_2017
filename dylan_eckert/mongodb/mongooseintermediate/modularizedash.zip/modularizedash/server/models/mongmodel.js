// require mongoose
var mongoose = require('mongoose');
// Creating MongooseSchema
var MongooseSchema = new mongoose.Schema({
  // NEED the required:true feild in order for errors to occur!
  name: {type:String, required: true},
  age: {type:Number, required: true},
}, {timestamps:true});
// Setting this schema in our models to be called 'Mongoose'
var Mongoose = mongoose.model('Mongoose', MongooseSchema);
