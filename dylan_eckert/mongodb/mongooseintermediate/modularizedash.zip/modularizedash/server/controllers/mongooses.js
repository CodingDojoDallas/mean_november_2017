var mongoose = require('mongoose');
var Mongoose = mongoose.model('Mongoose');

module.exports = {
  showAll: function(req, res){
    Mongoose.find({}, function(err, mongooses) {
      if (err) {console.log(err);}
      console.log(mongooses);
      res.render('index', { mongooses: mongooses });
    });
  },
  showProf: function(req, res){
    Mongoose.find({name: req.params.name}, function(err, mongoose){
      if (err) {console.log(err);}
      console.log(mongoose);
      res.render('monprof', { mongoose: mongoose });
    });
  },
  showEdit: function(req, res){
    Mongoose.find({name: req.params.name}, function(err, mongoose){
      if (err) {console.log(err);}
      console.log(mongoose);
      res.render('editmon', { mongoose: mongoose });
    });
  },
  create: function(req, res){
    let mongoose = new Mongoose (req.body);
    mongoose.save(function(err, mongoose){
      if (err) {
          console.log(err);
          return res.redirect('/mongooses/new');
      }else {
        console.log(mongoose)
        return res.redirect('/');
      }
    });
  },
  update: function(req, res){
    Mongoose.update({name: req.params.name}, req.body, function(err){
      if (err) {
          console.log(err);
          return res.redirect('/mongooses/edit/' + req.params.id);
      }else {
        return res.redirect('/');
      }
    });
  },
  destroy: function(req, res){
    Mongoose.remove({name: req.params.name}, function(err){
      if (err) {console.log(err);}
      res.redirect('/');
    });
  },
}
