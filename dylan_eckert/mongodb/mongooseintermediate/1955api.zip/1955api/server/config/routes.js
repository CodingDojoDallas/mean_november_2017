var humans = require('../controllers/humans.js');
module.exports = function(app) {
  // Routes
  // GETTERS/GET
  // homepage
app.get('/', function(req, res) {
    humans.showAll(req, res);
  });
  // new human
app.get('/new/:name', function(req, res) {
    humans.create(req, res);
  });
  // destroy human
app.get('/remove/:name', function(req, res) {
    humans.destroy(req, res);
  });
  // profile page
app.get('/:name', function(req, res) {
    humans.showHuman(req, res);
  });
}
