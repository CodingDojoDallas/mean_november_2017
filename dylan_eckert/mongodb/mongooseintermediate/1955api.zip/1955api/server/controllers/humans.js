var mongoose = require('mongoose');
var Human = mongoose.model('Human');

module.exports = {
  showAll: function(req, res){
    Human.find({}, function(err, humans) {
      if (err) {console.log(err);}
      console.log(humans);
      res.json(humans);
    });
  },
  showHuman: function(req, res){
    Human.find({name: req.params.name}, function(err, human){
      if (err) {console.log(err);}
      console.log(human);
      res.json(human);
    });
  },
  create: function(req, res){
    let human = new Human (req.params);
    human.save(function(err, human){
      if (err) {
          console.log(err);
          return res.redirect('/');
      }else {
        console.log(human)
        return res.redirect('/');
      }
    });
  },
  destroy: function(req, res){
    Human.remove({name: req.params.name}, function(err){
      if (err) {console.log(err);}
      res.redirect('/');
    });
  },
}
