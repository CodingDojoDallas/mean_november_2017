// require mongoose
var mongoose = require('mongoose');
// Creating MongooseSchema
var HumanSchema = new mongoose.Schema({
  // NEED the required:true feild in order for errors to occur!
  name: {type:String, required: true},
});
// Setting this schema in our models to be called 'Mongoose'
var Human = mongoose.model('Human', HumanSchema);
