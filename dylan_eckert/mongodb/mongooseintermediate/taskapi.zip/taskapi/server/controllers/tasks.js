var mongoose = require('mongoose');
var Task = mongoose.model('Task');

module.exports = {
  showAll: function(req, res){
    Task.find({}, function(err, tasks) {
      if (err) {console.log(err);}
      console.log(tasks);
      res.json(tasks);
    });
  },
  showTask: function(req, res){
    Task.find({_id: req.params.id}, function(err, task){
      if (err) {console.log(err);}
      console.log(task);
      res.json(task);
    });
  },
  create: function(req, res){
    let task = new Task (req.body);
    task.save(function(err, task){
      if (err) {
          console.log(err);
          return res.redirect('/tasks');
      }else {
        console.log(task)
        return res.redirect('/tasks');
      }
    });
  },
  update: function(req, res){
    Task.update({_id: req.params.id}, req.body, function(err){
      if (err) {
          console.log(err);
          return res.redirect('/tasks/' + req.params.id);
      }else {
        return res.redirect('/');
      }
    });
  },
  destroy: function(req, res){
    Task.remove({_id: req.params.id}, function(err){
      if (err) {console.log(err);}
      res.redirect('/tasks');
    });
  },
}
