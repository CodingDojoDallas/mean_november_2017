var tasks = require('../controllers/tasks.js');
module.exports = function(app) {
  // Routes
  // GETTERS/GET
  // homepage
app.get('/tasks', function(req, res) {
    tasks.showAll(req, res);
  });
  // task profile page
app.get('/tasks/:id', function(req, res) {
    tasks.showTask(req, res);
  });
  // new task
app.post('/tasks', function(req, res) {
    tasks.create(req, res);
  });
  // update task
app.put('/tasks/:id', function(req, res) {
    tasks.update(req, res);
  });
  // destroy task
app.delete('/tasks/:id', function(req, res) {
    tasks.destroy(req, res);
  });
}
