// require mongoose
var mongoose = require('mongoose');
// Creating MongooseSchema
var TaskSchema = new mongoose.Schema({
  // NEED the |required:true| feild in order for errors to occur!
  title: {type:String},
  description: {type:String},
  completed: {type:Boolean},
},{timestamps:true});
// Setting this schema in our models to be called 'Mongoose'
var Task = mongoose.model('Task', TaskSchema);
