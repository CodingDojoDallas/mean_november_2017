module.exports = {
    '/': 'index.html',
    '/cars' : 'cars.html',
    '/cats' : 'cats.html',
};
